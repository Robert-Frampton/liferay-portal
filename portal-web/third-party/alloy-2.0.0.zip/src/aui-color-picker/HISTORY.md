AUI Color Picker
========

@VERSION@
------

	* #AUI-983 - ColorPickerPopover does not display properly when more than one node is set as trigger
